/*
**
**                           Main.c
**
**
**********************************************************************/
/*
   Last committed:     $Revision: 00 $
   Last changed by:    $Author: $
   Last changed date:  $Date:  $
   ID:                 $Id:  $

**********************************************************************/
#include <stm32f10x_conf.h>

#include <stm32f10x_rcc.h>
#include <stm32f10x_gpio.h>
#define RCC_GPIO RCC_APB2Periph_GPIOB
#define LED_PORT GPIOB
#define LEDgrn_PIN GPIO_Pin_10
#define LEDred_PIN GPIO_Pin_11

#define BTN_PORT GPIOB
#define BTNred_PIN GPIO_Pin_12
#define BTNgrn_PIN GPIO_Pin_14


void Delay(volatile uint32_t nCount) {
for (; nCount != 0; nCount--);
}

int main(void) {
/* SystemInit() startup_stm32f10x_md_vl.c */

RCC_APB2PeriphClockCmd(RCC_GPIO, ENABLE);

GPIO_InitTypeDef GPIO_InitStructure;

GPIO_InitStructure.GPIO_Pin = LEDgrn_PIN | LEDred_PIN;
GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
GPIO_Init( LED_PORT , &GPIO_InitStructure);

GPIO_InitStructure.GPIO_Pin = BTNred_PIN | BTNgrn_PIN;
GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
GPIO_Init( BTN_PORT , &GPIO_InitStructure);


LED_PORT->ODR ^= LEDred_PIN;
while (1) {
  if ( GPIO_ReadInputDataBit( BTN_PORT, BTNred_PIN ) ) { // ( BTN_PORT->IDR & BTN1_PIN )
    GPIO_ResetBits( LED_PORT, LEDred_PIN);
  } else {
    GPIO_SetBits( LED_PORT, LEDred_PIN);
//    LED_PORT->ODR ^= LEDred_PIN; // blink when btn pressed
  };
  LED_PORT->ODR ^= LEDgrn_PIN;
//  LED_PORT->ODR ^= LEDred_PIN; // blink when btn pressed
  Delay(0x7FFFF);
}
return 0;
}
